
import matplotlib.pyplot as plt
import os

# Project output directory

output_dir = "visualizations"
os.makedirs(output_dir, exist_ok=True)

# Model Accuracy Comparison

models = ["Decision Tree", "Logistic Regression"]
accuracies = [93.10, 100.00]

plt.figure(figsize=(8, 5))

bars = plt.bar(models, accuracies)

plt.title("Wine Classification - Model Accuracy Comparison")
plt.xlabel("Machine Learning Models")
plt.ylabel("Accuracy (%)")
plt.ylim(0, 110)

for bar, accuracy in zip(bars, accuracies):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 1,
        f"{accuracy:.2f}%",
        ha="center"
    )

plt.tight_layout()
plt.savefig(os.path.join(output_dir, "model_accuracy.png"), dpi=300)
plt.show()

# 2. Decision Tree Feature Importance

features = [
    "Proline",
    "OD280_OD315",
    "Flavanoids",
    "Alcalinity_of_Ash",
    "Alcohol",
    "Malic_Acid"
]

importance = [
    0.360267,
    0.331728,
    0.134069,
    0.105289,
    0.039424,
    0.029223
]

plt.figure(figsize=(9, 5))

plt.barh(features[::-1], importance[::-1])

plt.title("Decision Tree - Feature Importance")
plt.xlabel("Importance Score")
plt.ylabel("Wine Features")

plt.tight_layout()
plt.savefig(os.path.join(output_dir, "feature_importance.png"), dpi=300)
plt.show()

print("Both visualizations saved successfully!")
